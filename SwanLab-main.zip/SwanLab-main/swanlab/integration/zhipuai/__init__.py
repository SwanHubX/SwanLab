#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""
@DATE: 2024-04-26 17:06:22
@File: swanlab\integration\zhipuai\__init__.py
@IDE: vscode
@Description:
    ZhipuAI 集成
"""
from .zhipuai import autolog
