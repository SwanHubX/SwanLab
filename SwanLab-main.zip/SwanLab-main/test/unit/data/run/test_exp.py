#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""
@DATE: 2024/6/3 01:26
@File: test_exp.py
@IDE: pycharm
@Description:
    测试运行实验类
"""


def test_exp_add_ok():
    pass


def test_exp_add_wrong_type():
    pass
