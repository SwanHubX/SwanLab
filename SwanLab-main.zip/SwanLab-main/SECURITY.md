# Security Policy

## Reporting a Vulnerability

Please report security vulnerabilities by email to `zeyi.lin@swanhub.co`.
This email is an alias to a subset of our maintainers, and will ensure the issue is promptly triaged and acted upon as needed.