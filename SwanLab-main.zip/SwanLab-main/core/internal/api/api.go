// @Title        api.go
// @Description  SwanLab API intended for requests to the SwanLab Server.
// @Create       cunyue 2025/6/10 13:00

package api
